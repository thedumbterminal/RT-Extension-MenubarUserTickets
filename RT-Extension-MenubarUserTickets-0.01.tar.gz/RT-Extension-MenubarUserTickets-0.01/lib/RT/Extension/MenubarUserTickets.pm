use warnings;
use strict;

package RT::Extension::MenuBarUserTickets;

our $VERSION = '0.01';

1;
