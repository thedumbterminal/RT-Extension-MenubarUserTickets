use warnings;
use strict;

package RT::Extension::MenuBarSearches;

our $VERSION = '0.04';

1;
