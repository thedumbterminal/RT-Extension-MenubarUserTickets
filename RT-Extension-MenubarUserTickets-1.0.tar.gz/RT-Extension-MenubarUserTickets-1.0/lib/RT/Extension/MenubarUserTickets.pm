use warnings;
use strict;
use 5.8.3;	#this is what RT requires http://wiki.bestpractical.com/view/ManualRequirements
package RT::Extension::MenuBarUserTickets;

our $VERSION = '1.0';

return 1;

=pod

=head1 Author

MacGyveR <dumb@cpan.org>

Development questions, bug reports, and patches are welcome to the above address

=head1 Copyright

Copyright (c) 2009 MacGyveR. All rights reserved.

This library is free software; you can redistribute it and/or modify it under the same terms as Perl itself.

=cut
